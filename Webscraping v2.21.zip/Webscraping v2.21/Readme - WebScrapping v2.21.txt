Versión: WebScrapping 2.21

Estado general del proyecto
En la versión actual (WebScrapping 2.21), el proceso de web scraping funciona de manera estable. El scraper logra recorrer correctamente las páginas disponibles, aunque hasta el momento no ha conseguido superar el umbral de aproximadamente 40 páginas. A partir de este proceso se recolectan alrededor de 4,000 registros de datos crudos. Después de la etapa de limpieza, se obtienen aproximadamente entre 3,700 y 3,800 observaciones válidas.

Simulación Monte Carlo
Con los datos limpios se ejecuta una simulación tipo Monte Carlo; sin embargo, la implementación actual se realiza mediante Bootstrap. De acuerdo con los señalamientos del profesor, esta implementación no corresponde a una simulación de Monte Carlo correctamente planteada. En versiones posteriores será necesario revisar de manera formal la metodología de simulación y definir con precisión qué elementos deben incorporarse para que la simulación Monte Carlo sea estadísticamente correcta (definición de distribuciones, supuestos, generación de escenarios y justificación teórica).

Modelo econométrico
Posteriormente se plantea un modelo econométrico. El modelo actual funciona correctamente desde el punto de vista técnico y econométrico, pero presenta una limitación importante: cuenta con pocas variables explicativas. Por esta razón, en las siguientes versiones se buscará ampliar el conjunto de variables, lo cual implica modificar el proceso de scraping para ingresar a cada anuncio de manera individual y extraer mayor información específica de cada inmueble.

Obtención de código postal y localización
Una observación adicional del profesor fue la necesidad de contar con el código postal del inmueble anunciado. Una posible solución propuesta consiste en aprovechar que, dentro del código HTML del anuncio, existe un recuadro con una imagen de Google Maps. A partir de dicha imagen es posible obtener las coordenadas geográficas (latitud y longitud) y, posteriormente, utilizar una función o servicio en Python para realizar geocodificación inversa y obtener el código postal. Esta estrategia debe analizarse y validarse con mayor detalle en versiones posteriores.

Clusterización
Después del modelo econométrico se realiza un proceso de clusterización. En la versión actual, la clusterización funciona correctamente y se lleva a cabo de dos formas:

Clusterización con una sola variable (precio).

Clusterización con cuatro variables (precio, recámaras, superficie y baños).

Asimismo, se generan y visualizan las gráficas correspondientes para ambos casos. No obstante, este esquema deberá ajustarse en el futuro, ya que al incorporar más variables el análisis de clúster cambiará. La propuesta es no modificar las celdas de clusterización ya implementadas, sino agregar nuevas celdas que realicen la clusterización utilizando todas las variables adicionales que se logren recolectar, junto con sus respectivas gráficas.

Reducción dimensional
Finalmente, el profesor indicó que la reducción dimensional implementada no es pertinente en esta etapa del proyecto. Dado que actualmente se cuenta con un número reducido de variables, la reducción dimensional no aporta valor analítico y resulta innecesaria. Este punto deberá reconsiderarse únicamente cuando se disponga de un conjunto de variables suficientemente amplio que justifique formalmente la aplicación de técnicas de reducción dimensional.

Estado general
En resumen, WebScrapping 2.21 es una versión funcional y estable, que sirve como base sólida para futuras mejoras. Las siguientes etapas del proyecto se enfocarán en:

Mejorar la simulación Monte Carlo.

Ampliar el número de variables mediante un scraping más profundo.

Incorporar información geográfica como el código postal.

Extender la clusterización a conjuntos de variables más amplios.

Replantear la reducción dimensional solo cuando sea metodológicamente justificable.