WebScraping v2.26

Versión: WebScraping v2.26

En esta versión del proyecto se logró restaurar y agregar correctamente la columna Unidades, permitiendo contabilizar el número real de unidades disponibles por anuncio.
Este cambio corrige la limitación de versiones anteriores, donde únicamente se contabilizaban anuncios y no el total real de unidades a la venta.

El proceso de scraping se mantiene estable, utilizando navegación real por cada anuncio para obtener la información necesaria sin alterar la lógica principal que ya funciona.

Pendiente para la siguiente versión:
En la próxima versión del proyecto se agregará la columna de ubicación con la información completa y correcta, extrayendo el texto directamente desde el anuncio individual.
Esto permitirá mejorar la calidad del dataset y la precisión del análisis geográfico de los inmuebles.

A partir de WebScraping v2.26, el proyecto vuelve a contar con una base sólida para continuar agregando nuevas variables de forma incremental y controlada.