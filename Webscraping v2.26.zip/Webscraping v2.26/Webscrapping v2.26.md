```python
# ================== WEBSCRAPING 2.25 - CELDA 1/3: IMPORTS + CONSTANTES + AUXILIARES ==================
# Qué hace:
# - Imports mínimos del wrapper (WS 2.25)
# - Constantes de salida
# - parsear_precio_mxn() para asegurar Precio_num al cargar

import os
import re
import numpy as np
import pandas as pd

RAW_CSV = "Casas_raw.csv"
LIMPIO_CSV = "Casas_limpio.csv"

TIPO_CAMBIO_USD_MXN = 18.0

def parsear_precio_mxn(texto, tipo_cambio: float = TIPO_CAMBIO_USD_MXN):
    if texto is None or (isinstance(texto, float) and np.isnan(texto)):
        return np.nan
    s = str(texto).lower()

    moneda = "MXN"
    if ("usd" in s or "us$" in s or "u$s" in s or "dólar" in s or "dolar" in s):
        moneda = "USD"

    m = re.search(r"(\d[\d,\.]*)", str(texto))
    if not m:
        return np.nan

    try:
        valor = float(m.group(1).replace(",", ""))
    except ValueError:
        return np.nan

    if moneda == "USD":
        valor *= tipo_cambio

    return valor

```


```python
# ================== WEBSCRAPING 2.25 - CELDA 2/3: EJECUTAR scraper_runner.ipynb EN ESTE KERNEL ==================
# Qué hace:
# - Corre scraper_runner.ipynb con %run -i (mismo kernel)
# - Evita que SystemExit tumbe el kernel
# - Evita doble ejecución: SOLO llama main() si el runner NO generó/actualizó CSVs

import os
import traceback
from IPython import get_ipython

SCRAPER_NOTEBOOK = os.path.join(os.getcwd(), "scraper_runner.ipynb")
if not os.path.exists(SCRAPER_NOTEBOOK):
    raise FileNotFoundError(f"No existe: {SCRAPER_NOTEBOOK}")

def _mtime(path: str):
    return os.path.getmtime(path) if os.path.exists(path) else None

raw_before = _mtime(RAW_CSV)
limpio_before = _mtime(LIMPIO_CSV)

print("Ejecutando:", SCRAPER_NOTEBOOK)

try:
    get_ipython().run_line_magic("run", f'-i "{SCRAPER_NOTEBOOK}"')
except SystemExit as e:
    print(f"[WARN] SystemExit atrapado al ejecutar el runner: {e}")
except Exception:
    print("[ERROR] Fallo ejecutando el runner.")
    traceback.print_exc()
    raise

raw_after = _mtime(RAW_CSV)
limpio_after = _mtime(LIMPIO_CSV)

runner_ya_genero_outputs = (
    (raw_after is not None and raw_before != raw_after) or
    (limpio_after is not None and limpio_before != limpio_after)
)

if runner_ya_genero_outputs:
    print("El runner YA generó/actualizó CSVs. No se llama main() (evitar doble ejecución).")
else:
    try:
        if "main" in globals() and callable(globals()["main"]):
            ret = globals()["main"]()
            print("Scraping terminado. main() retornó:", ret)
        else:
            print("No existe main() en globals() y el runner no generó outputs. Revisa runner.")
    except SystemExit as e:
        print(f"[WARN] SystemExit atrapado dentro de main(): {e}")
    except Exception:
        print("[ERROR] Fallo dentro de main().")
        traceback.print_exc()
        raise

```

    Ejecutando: C:\Users\yasc1\Documents\Ingenieria financiera\Webscraping2\Webscraping v2.26\scraper_runner.ipynb
    URL inicial: https://inmuebles.mercadolibre.com.mx/casas/venta/distrito-federal/_DisplayType_M
    Sesión OK / listado cargado (no se pidió login).
    Abriendo: https://inmuebles.mercadolibre.com.mx/casas/venta/distrito-federal/_DisplayType_M
    Página 1 | intento 1 | cards candidatos: 100
    Página 2 | intento 1 | cards candidatos: 100
    Página 3 | intento 1 | cards candidatos: 100
    Página 4 | intento 1 | cards candidatos: 100
    Página 5 | intento 1 | cards candidatos: 100
    Página 6 | intento 1 | cards candidatos: 100
    Página 7 | intento 1 | cards candidatos: 100
    Página 8 | intento 1 | cards candidatos: 100
    Página 9 | intento 1 | cards candidatos: 100
    Página 10 | intento 1 | cards candidatos: 100
    Página 11 | intento 1 | cards candidatos: 100
    Página 12 | intento 1 | cards candidatos: 96
    Página 13 | intento 1 | cards candidatos: 100
    Página 14 | intento 1 | cards candidatos: 100
    Página 15 | intento 1 | cards candidatos: 100
    Página 16 | intento 1 | cards candidatos: 100
    Página 17 | intento 1 | cards candidatos: 100
    Página 18 | intento 1 | cards candidatos: 100
    Página 19 | intento 1 | cards candidatos: 100
    Página 20 | intento 1 | cards candidatos: 100
    Página 21 | intento 1 | cards candidatos: 100
    Página 22 | intento 1 | cards candidatos: 100
    Página 23 | intento 1 | cards candidatos: 100
    Página 24 | intento 1 | cards candidatos: 100
    Página 25 | intento 1 | cards candidatos: 100
    Página 26 | intento 1 | cards candidatos: 100
    Página 27 | intento 1 | cards candidatos: 100
    Página 28 | intento 1 | cards candidatos: 100
    Página 29 | intento 1 | cards candidatos: 100
    Página 30 | intento 1 | cards candidatos: 100
    Página 31 | intento 1 | cards candidatos: 100
    Página 32 | intento 1 | cards candidatos: 100
    Página 33 | intento 1 | cards candidatos: 100
    Página 34 | intento 1 | cards candidatos: 100
    Página 35 | intento 1 | cards candidatos: 100
    Página 36 | intento 1 | cards candidatos: 98
    Página 37 | intento 1 | cards candidatos: 100
    Página 38 | intento 1 | cards candidatos: 72
    Página 39 | intento 1 | cards candidatos: 100
    Página 40 | intento 1 | cards candidatos: 100
    No se pudo avanzar a 'Siguiente' (o no hay más). Stop paginación.
    Fin. crudos=3966 | limpios=3966
    Guardado Casas_raw.csv
    No se pudo guardar Casas_raw.xlsx: No module named 'openpyxl'
    Guardado Casas_raw.xml
    Guardado Casas_limpio.csv
    No se pudo guardar Casas_limpio.xlsx: No module named 'openpyxl'
    Guardado Casas_limpio.xml
    Scraping terminado. main() retornó: {'ok': True, 'raw': 3966, 'limpio': 3966, 'tiempo': 21571.488976716995}
    


```python
# ================== WEBSCRAPING 2.25 - CELDA 3/3: CARGA + VALIDACIÓN + ASEGURAR Precio_num ==================
# Qué hace:
# - Verifica que existan los 2 CSV
# - Carga df_raw y df_limpio
# - Asegura columna Precio_num (si no existe, la crea desde Precio)

import os
import pandas as pd
import numpy as np

if not (os.path.exists(RAW_CSV) and os.path.exists(LIMPIO_CSV)):
    raise FileNotFoundError(
        f"No encuentro {RAW_CSV} o {LIMPIO_CSV}. Revisa la salida de la CELDA 2."
    )

df_raw = pd.read_csv(RAW_CSV, encoding="utf-8-sig")
df_limpio = pd.read_csv(LIMPIO_CSV, encoding="utf-8-sig")

if "Precio_num" not in df_limpio.columns:
    if "Precio" in df_limpio.columns:
        df_limpio["Precio_num"] = df_limpio["Precio"].apply(parsear_precio_mxn)
    else:
        df_limpio["Precio_num"] = np.nan

print("raw:", df_raw.shape, "| limpio:", df_limpio.shape)
df_limpio.head()

```

    raw: (3966, 8) | limpio: (3966, 9)
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Link</th>
      <th>Direccion</th>
      <th>Ubicacion_card</th>
      <th>Precio</th>
      <th>Precio_num</th>
      <th>Recamaras</th>
      <th>Superficie_m2</th>
      <th>Banos</th>
      <th>Unidades</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>https://casa.mercadolibre.com.mx/MLM-257886171...</td>
      <td>Reserva del sur</td>
      <td>NaN</td>
      <td>MXN 4,600,000</td>
      <td>4600000.0</td>
      <td>3.0</td>
      <td>130.0</td>
      <td>3.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>https://casa.mercadolibre.com.mx/MLM-257886171...</td>
      <td>Reserva del sur</td>
      <td>NaN</td>
      <td>MXN 4,600,000</td>
      <td>4600000.0</td>
      <td>3.0</td>
      <td>130.0</td>
      <td>3.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>https://casa.mercadolibre.com.mx/MLM-254901132...</td>
      <td>Vitant Santa Fe By Be Grand</td>
      <td>NaN</td>
      <td>MXN 3,700,000</td>
      <td>3700000.0</td>
      <td>1.0</td>
      <td>65.0</td>
      <td>1.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>https://casa.mercadolibre.com.mx/MLM-254901132...</td>
      <td>Vitant Santa Fe By Be Grand</td>
      <td>NaN</td>
      <td>MXN 3,700,000</td>
      <td>3700000.0</td>
      <td>1.0</td>
      <td>65.0</td>
      <td>1.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>https://casa.mercadolibre.com.mx/MLM-237504558...</td>
      <td>Casa Venta Heroes De Padierna ¡el Balance Perf...</td>
      <td>NaN</td>
      <td>MXN 6,990,000</td>
      <td>6990000.0</td>
      <td>4.0</td>
      <td>335.0</td>
      <td>3.0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>


