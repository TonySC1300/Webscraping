```python
# ================== SCRAPERUNNER - CELDA 1/7: IMPORTS + PARÁMETROS GLOBALES ==================
# (ANTES: CELDA 1/6) -> (AHORA: CELDA 1/7) [sin cambios funcionales, solo renumeración]

import os
import re
import time
import random
from typing import Optional, Tuple, List

import numpy as np
import pandas as pd
from bs4 import BeautifulSoup

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager

from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys  # <-- NUEVO (para CTRL+CLICK)
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from selenium.common.exceptions import TimeoutException  # <-- NUEVO

PAGINA_INICIO = 1
PAGINA_FIN = 60
BASE_URL = "https://inmuebles.mercadolibre.com.mx/casas/venta/distrito-federal/_DisplayType_M"

OBJETIVO_LIMPIOS = 5000
OBJETIVO_CRUDO_MINIMO = 6000
TIPO_CAMBIO_USD_MXN = 18.0

RAW_BASENAME = "Casas_raw"
LIMPIO_BASENAME = "Casas_limpio"
RAW_CSV = f"{RAW_BASENAME}.csv"
LIMPIO_CSV = f"{LIMPIO_BASENAME}.csv"

WAIT_TIMEOUT = 20
PAGELOAD_TIMEOUT = 60

# ===== PERFIL DEDICADO (RECOMENDADO) =====
CHROME_USER_DATA_DIR = r"C:\chrome_profiles\ml"  # carpeta nueva dedicada
CHROME_PROFILE_DIR = "Default"                  # déjalo así

```


```python
# ================== SCRAPERUNNER - CELDA 2/7: UTILIDADES (TIMER + PARSEO + EXTRACTORES) ==================
# (ANTES: CELDA 2/6) -> (AHORA: CELDA 2/7) [sin cambios funcionales, solo renumeración]

class HumanTimer:
    def __init__(self):
        self.last_delay = random.uniform(0.1, 0.8)

    def wait(self, min_s=0.2, max_s=1.0, extra_jitter=(0.02, 0.5)):
        if min_s < 0:
            min_s = 0.0
        if max_s < min_s:
            max_s = min_s + 0.1

        base = random.uniform(min_s, max_s)
        correlated = 0.7 * base + 0.3 * self.last_delay
        jitter = random.uniform(*extra_jitter)
        if random.random() < 0.3:
            jitter *= random.uniform(1.0, 2.5)

        delay = max(0.05, correlated + jitter)
        if random.random() < 0.1:
            delay += random.uniform(0.05, 0.4)

        self.last_delay = delay
        time.sleep(delay)


def parsear_precio_mxn(texto: Optional[str]) -> float:
    if texto is None or (isinstance(texto, float) and np.isnan(texto)):
        return np.nan

    s = str(texto)
    s_lower = s.lower()

    moneda = "MXN"
    if ("usd" in s_lower or "us$" in s_lower or "u$s" in s_lower or
        "dólar" in s_lower or "dolar" in s_lower):
        moneda = "USD"

    m = re.search(r"(\d[\d,\.]*)", s)
    if not m:
        return np.nan

    valor_str = m.group(1).replace(",", "")
    try:
        valor = float(valor_str)
    except ValueError:
        return np.nan

    if moneda == "USD":
        valor *= TIPO_CAMBIO_USD_MXN

    return valor


def extraer_recamaras_superficie(card) -> Tuple[Optional[float], Optional[float]]:
    txt = card.get_text(" ", strip=True).lower()

    recamaras = None
    superficie = None

    m_rec = re.search(r"(\d+)\s*rec[aá]m", txt)
    if m_rec:
        recamaras = float(m_rec.group(1))

    m_sup = re.search(r"(\d+(?:\.\d+)?)\s*(m2|m²)", txt.replace(",", ""))
    if m_sup:
        superficie = float(m_sup.group(1))

    return recamaras, superficie


def extraer_banos_desde_texto(texto: Optional[str]) -> Optional[float]:
    if not texto:
        return None
    txt = str(texto).lower()
    m = re.search(r"(\d+(?:\.\d+)?)\s*bañ", txt)
    if not m:
        return None
    try:
        return float(m.group(1))
    except ValueError:
        return None

```


```python
# ================== SCRAPERUNNER - CELDA 3/7: DRIVER PERSISTENTE (ROBUSTO) + LOGIN 2FA (TIEMPO AMPLIO) ==================
# (ANTES: CELDA 3/6) -> (AHORA: CELDA 3/7) [sin cambios funcionales, solo renumeración]

import os
import time

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException


CHROME_USER_DATA_DIR = r"C:\chrome_profiles\ml"
CHROME_PROFILE_DIR   = "Default"

PAGELOAD_TIMEOUT = 60
WAIT_TIMEOUT = 20


def crear_driver_persistente() -> webdriver.Chrome:
    options = Options()
    options.add_argument("--start-maximized")
    options.add_argument("--disable-notifications")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--no-first-run")
    options.add_argument("--no-default-browser-check")

    os.makedirs(CHROME_USER_DATA_DIR, exist_ok=True)
    options.add_argument(f"--user-data-dir={CHROME_USER_DATA_DIR}")

    if CHROME_PROFILE_DIR:
        options.add_argument(f"--profile-directory={CHROME_PROFILE_DIR}")

    service = Service(ChromeDriverManager().install())

    try:
        driver = webdriver.Chrome(service=service, options=options)
        driver.set_page_load_timeout(PAGELOAD_TIMEOUT)
        return driver

    except Exception as e:
        msg = str(e).lower()
        if "cannot create default profile directory" in msg or "session not created" in msg:
            print("[WARN] Falló iniciar Chrome con profile-directory. Reintentando sin profile-directory...")

            options2 = Options()
            options2.add_argument("--start-maximized")
            options2.add_argument("--disable-notifications")
            options2.add_argument("--disable-blink-features=AutomationControlled")
            options2.add_argument("--no-first-run")
            options2.add_argument("--no-default-browser-check")

            os.makedirs(CHROME_USER_DATA_DIR, exist_ok=True)
            options2.add_argument(f"--user-data-dir={CHROME_USER_DATA_DIR}")

            driver = webdriver.Chrome(service=service, options=options2)
            driver.set_page_load_timeout(PAGELOAD_TIMEOUT)
            return driver

        raise


def esperar_login_y_volver(driver: webdriver.Chrome, url_objetivo: str, max_minutos: int = 15):
    driver.get(url_objetivo)
    print("URL inicial:", driver.current_url)

    try:
        WebDriverWait(driver, 6).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "div.ui-search-result, div.ui-search-map-list__item"))
        )
        print("Sesión OK / listado cargado (no se pidió login).")
        return
    except Exception:
        pass

    print(f"Login requerido. Tienes hasta {max_minutos} minutos para completar login + código (2FA).")
    print("1) Completa el login en la ventana de Chrome.")
    print("2) Mete el código de verificación si te lo pide.")
    print("3) Cuando ya veas que tu sesión está iniciada, REGRESA AQUÍ y presiona Enter.")
    input()

    driver.get(url_objetivo)
    print("URL post-login (forzada):", driver.current_url)

    t_end = time.time() + max_minutos * 60
    while True:
        try:
            WebDriverWait(driver, 8).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "div.ui-search-result, div.ui-search-map-list__item"))
            )
            print("OK: listado detectado.")
            return
        except TimeoutException:
            if time.time() > t_end:
                raise TimeoutError(
                    f"No se detectó el listado en {max_minutos} min. "
                    "Probable: sigues en login/2FA, te redirigió a otra página, o cambió el DOM."
                )

            print("Aún no detecto el listado. Reintentando volver a url_objetivo...")
            driver.get(url_objetivo)
            time.sleep(2)

```


```python
# ================== SCRAPERUNNER - CELDA 4/7: SCROLL + CLICK SIGUIENTE ==================
# (ANTES: CELDA 4/6) -> (AHORA: CELDA 4/7) [sin cambios funcionales, solo renumeración]

def human_scroll_page(driver: webdriver.Chrome, timer: HumanTimer, min_steps=3, max_steps=6):
    try:
        total_height = driver.execute_script("return document.body.scrollHeight") or 0
    except Exception:
        return

    if total_height <= 0:
        return

    steps = random.randint(min_steps, max_steps)
    for _ in range(steps):
        target = int(total_height * random.uniform(0.1, 0.95))
        driver.execute_script("window.scrollTo(0, arguments[0]);", target)
        timer.wait(0.2, 0.9, extra_jitter=(0.0, 0.3))

    if random.random() < 0.4:
        target = int(total_height * random.uniform(0.0, 0.4))
        driver.execute_script("window.scrollTo(0, arguments[0]);", target)
        timer.wait(0.3, 1.0, extra_jitter=(0.0, 0.3))


def click_siguiente(driver: webdriver.Chrome, timer: HumanTimer) -> bool:
    try:
        human_scroll_page(driver, timer, min_steps=2, max_steps=4)
        timer.wait(0.8, 2.0, extra_jitter=(0.1, 0.5))

        xpath = (
            "//span[contains(@class,'andes-pagination__arrow-title') "
            "and normalize-space()='Siguiente']"
        )
        span_next = WebDriverWait(driver, WAIT_TIMEOUT).until(
            EC.presence_of_element_located((By.XPATH, xpath))
        )
        next_btn = span_next.find_element(By.XPATH, "./ancestor::a | ./ancestor::button")

        aria_disabled = (next_btn.get_attribute("aria-disabled") or "").lower()
        classes = (next_btn.get_attribute("class") or "").lower()
        if "true" in aria_disabled or "disabled" in classes:
            return False

        ActionChains(driver).move_to_element(next_btn).pause(random.uniform(0.2, 0.8)).click().perform()
        timer.wait(2.0, 5.0, extra_jitter=(0.1, 0.7))
        return True

    except Exception:
        return False

```


```python
# ================== SCRAPERUNNER - CELDA 5/7 (NUEVA): CLICK EN ANUNCIO + CONTEO "UNIDADES DISPONIBLES" ==================
# NUEVA en v2.26:
# - Se agrega una extracción por anuncio: abrir (click real) cada tarjeta en una pestaña nueva
# - Ya en el detalle, contar cuántas unidades hay dentro de "Unidades disponibles"
# - Si no existe esa sección, se asume 1 unidad (anuncio simple)

def _contar_unidades_en_detalle_html(html: str) -> int:
    soup = BeautifulSoup(html, "html.parser")
    # Lo que viste en DevTools:
    # div.ui-vip-available-units__unit-container row-0, row-1, ...
    units = soup.select("div.ui-vip-available-units__unit-container")
    if units:
        return len(units)
    # Si no hay bloque de unidades disponibles, normalmente es 1 publicación (una sola unidad)
    return 1


def _abrir_anuncio_en_nueva_pestana(driver: webdriver.Chrome, timer: HumanTimer, card_el) -> bool:
    """
    Abre el anuncio con un CLICK real sobre el anchor de la tarjeta, usando CTRL+CLICK para pestaña nueva.
    Regresa True si se abrió una pestaña nueva.
    """
    handles_before = driver.window_handles[:]

    try:
        # Intentar el link dentro de la tarjeta
        a = card_el.find_element(By.CSS_SELECTOR, "a[href]")
    except Exception:
        # fallback: click sobre la tarjeta completa (a veces también abre)
        a = card_el

    try:
        ActionChains(driver)\
            .move_to_element(a)\
            .pause(random.uniform(0.1, 0.4))\
            .key_down(Keys.CONTROL)\
            .click(a)\
            .key_up(Keys.CONTROL)\
            .perform()
    except Exception:
        return False

    # Esperar que aparezca un handle nuevo
    t_end = time.time() + 8
    while time.time() < t_end:
        handles_after = driver.window_handles
        if len(handles_after) > len(handles_before):
            return True
        timer.wait(0.15, 0.35, extra_jitter=(0.0, 0.15))

    return False


def _leer_unidades_del_anuncio(driver: webdriver.Chrome, timer: HumanTimer) -> int:
    """
    Estando ya en la pestaña del detalle del anuncio:
    - espera carga mínima
    - intenta detectar "Unidades disponibles" (sin forzar)
    - cuenta containers y regresa entero
    """
    # Espera algo típico del PDP. Si falla, igual contamos por HTML.
    try:
        WebDriverWait(driver, 6).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "body"))
        )
    except Exception:
        pass

    # Un pequeño scroll (a veces el bloque se renderiza lazy)
    try:
        driver.execute_script("window.scrollTo(0, Math.min(900, document.body.scrollHeight));")
    except Exception:
        pass
    timer.wait(0.25, 0.8, extra_jitter=(0.0, 0.25))

    html = driver.page_source
    return _contar_unidades_en_detalle_html(html)

```


```python
# ================== SCRAPERUNNER - CELDA 6/7: SCRAP DEL LISTADO (AHORA SÍ ENTRA A LINKS CON CLICK) ==================
# (ANTES: CELDA 5/6) -> (AHORA: CELDA 6/7)
# CAMBIO MÍNIMO:
# - Se mantiene extracción del listado con BeautifulSoup
# - Se agrega: por cada card, abrir anuncio (CTRL+CLICK), contar unidades, cerrar pestaña, volver al listado
# - Se agrega columna: "Unidades"

def _extraer_cards_listado(soup: BeautifulSoup):
    return soup.select("div.ui-search-result, div.ui-search-map-list__item")


def scrapear_inmuebles_listado(driver: webdriver.Chrome) -> Tuple[pd.DataFrame, pd.DataFrame, float]:
    timer = HumanTimer()
    data_raw: List[dict] = []
    data_limpio: List[dict] = []

    t0 = time.time()

    print(f"Abriendo: {BASE_URL}")
    driver.get(BASE_URL)
    timer.wait(2.5, 6.0, extra_jitter=(0.05, 0.8))

    page = PAGINA_INICIO

    while True:
        cards_bs4 = []
        soup = None

        for intento in range(2):
            human_scroll_page(driver, timer, min_steps=2, max_steps=5)
            html = driver.page_source
            soup_tmp = BeautifulSoup(html, "html.parser")
            cards_tmp = _extraer_cards_listado(soup_tmp)

            print(f"Página {page} | intento {intento+1} | cards candidatos: {len(cards_tmp)}")
            if cards_tmp:
                cards_bs4 = cards_tmp
                soup = soup_tmp
                break

            timer.wait(1.0, 3.0, extra_jitter=(0.1, 0.6))

        if not cards_bs4:
            print("No se encontraron anuncios; se detiene.")
            break

        # Selenium cards (para poder hacer click real)
        cards_sel = driver.find_elements(By.CSS_SELECTOR, "div.ui-search-result, div.ui-search-map-list__item")

        n = min(len(cards_bs4), len(cards_sel))
        if n == 0:
            print("No pude empatar cards (bs4/selenium). Stop.")
            break

        for i in range(n):
            card = cards_bs4[i]
            card_el = cards_sel[i]

            a_tag = card.find("a", href=True)
            if not a_tag:
                continue
            link = a_tag["href"]

            titulo_tag = card.find("h2")
            direccion = titulo_tag.get_text(strip=True) if titulo_tag else None

            ubicacion_card = None
            loc_tag = card.select_one(".ui-search-item__location")
            if loc_tag:
                ubicacion_card = loc_tag.get_text(strip=True)
            else:
                loc_group = card.select_one(".ui-search-item__group--location")
                if loc_group:
                    ubicacion_card = loc_group.get_text(" ", strip=True)

            price_tag = card.select_one(".andes-money-amount__fraction")
            if price_tag:
                precio_text = price_tag.get_text(strip=True)
                precio = f"MXN {precio_text}"
            else:
                price_block = card.select_one(".ui-search-price")
                precio = price_block.get_text(" ", strip=True) if price_block else None

            recamaras, superficie = extraer_recamaras_superficie(card)
            banos = extraer_banos_desde_texto(card.get_text(" ", strip=True))

            # ===== NUEVO: CONTAR UNIDADES EN DETALLE (CLICK REAL) =====
            unidades = 1
            listado_handle = driver.current_window_handle
            handles_before = driver.window_handles[:]

            opened = _abrir_anuncio_en_nueva_pestana(driver, timer, card_el)
            if opened:
                # Cambiar a la pestaña nueva
                handles_after = driver.window_handles
                new_handles = [h for h in handles_after if h not in handles_before]
                if new_handles:
                    driver.switch_to.window(new_handles[0])
                    timer.wait(0.6, 1.6, extra_jitter=(0.0, 0.4))

                    try:
                        unidades = _leer_unidades_del_anuncio(driver, timer)
                    except Exception:
                        unidades = 1

                    # Cerrar pestaña detalle
                    try:
                        driver.close()
                    except Exception:
                        pass

                    # Volver al listado
                    try:
                        driver.switch_to.window(listado_handle)
                    except Exception:
                        # fallback: vuelve al primero
                        try:
                            driver.switch_to.window(driver.window_handles[0])
                        except Exception:
                            pass

                    timer.wait(0.25, 0.9, extra_jitter=(0.0, 0.25))

            # ===== guardar filas =====
            data_raw.append({
                "Link": link,
                "Direccion": direccion,
                "Ubicacion_card": ubicacion_card,
                "Precio": precio,
                "Recamaras": recamaras,
                "Superficie_m2": superficie,
                "Banos": banos,
                "Unidades": unidades,  # <-- NUEVO
            })

            precio_num = parsear_precio_mxn(precio) if precio is not None else np.nan
            if not np.isnan(precio_num):
                data_limpio.append({
                    "Link": link,
                    "Direccion": direccion,
                    "Ubicacion_card": ubicacion_card,
                    "Precio": precio,
                    "Precio_num": precio_num,
                    "Recamaras": recamaras,
                    "Superficie_m2": superficie,
                    "Banos": banos,
                    "Unidades": unidades,  # <-- NUEVO
                })

            if len(data_limpio) >= OBJETIVO_LIMPIOS:
                print(f"Se alcanzaron {OBJETIVO_LIMPIOS} limpios. Stop.")
                tiempo = time.time() - t0
                return pd.DataFrame(data_raw), pd.DataFrame(data_limpio), tiempo

            if len(data_raw) >= OBJETIVO_CRUDO_MINIMO:
                print(f"Se alcanzaron {OBJETIVO_CRUDO_MINIMO} crudos. Stop.")
                tiempo = time.time() - t0
                return pd.DataFrame(data_raw), pd.DataFrame(data_limpio), tiempo

            timer.wait(0.08, 0.5, extra_jitter=(0.0, 0.2))

        if page >= PAGINA_FIN:
            print(f"Límite PAGINA_FIN={PAGINA_FIN}. Stop paginación.")
            break

        if not click_siguiente(driver, timer):
            print("No se pudo avanzar a 'Siguiente' (o no hay más). Stop paginación.")
            break

        page += 1

    tiempo = time.time() - t0
    df_raw = pd.DataFrame(data_raw)
    df_limpio = pd.DataFrame(data_limpio)
    print(f"Fin. crudos={len(df_raw)} | limpios={len(df_limpio)}")
    return df_raw, df_limpio, tiempo

```


```python
# ================== SCRAPERUNNER - CELDA 7/7: GUARDADO + main() (SIN SystemExit) ==================
# (ANTES: CELDA 6/6) -> (AHORA: CELDA 7/7) [sin cambios funcionales, solo renumeración]

def guardar_para_excel(df: pd.DataFrame, base_name: str):
    try:
        df.to_csv(f"{base_name}.csv", index=False, encoding="utf-8-sig")
        print(f"Guardado {base_name}.csv")
    except Exception as e:
        print(f"No se pudo guardar {base_name}.csv:", e)

    try:
        df.to_excel(f"{base_name}.xlsx", index=False)
        print(f"Guardado {base_name}.xlsx")
    except Exception as e:
        print(f"No se pudo guardar {base_name}.xlsx:", e)

    try:
        df.to_xml(f"{base_name}.xml", index=False)
        print(f"Guardado {base_name}.xml")
    except Exception as e:
        print(f"No se pudo guardar {base_name}.xml:", e)


def main():
    """
    Entry point para WebScraping 2.26.
    IMPORTANTE: no hace SystemExit. Retorna dict de estado.
    """
    driver = crear_driver_persistente()
    try:
        esperar_login_y_volver(driver, BASE_URL)
        df_raw, df_limpio, tiempo = scrapear_inmuebles_listado(driver)
    finally:
        driver.quit()

    if df_raw is None or df_raw.empty:
        print("No se obtuvieron datos. No se guarda.")
        return {"ok": False, "raw": 0, "limpio": 0, "tiempo": tiempo}

    guardar_para_excel(df_raw, RAW_BASENAME)
    guardar_para_excel(df_limpio, LIMPIO_BASENAME)

    return {"ok": True, "raw": len(df_raw), "limpio": len(df_limpio), "tiempo": tiempo}

```


```python
# ================== SCRAPERUNNER - CELDA EXTRA (EXPORT MAIN): EXPONER main PARA RUNNER ==================
# Esto garantiza que el runner pueda encontrar una referencia estable a la función principal.

try:
    __SCRAPER_MAIN__ = main
except NameError:
    __SCRAPER_MAIN__ = None

```
